 
<?php include("header.php")?>
<?php include("nav.php")?>
<?php
 if (isset($_POST['insert'])) {
    require_once("config.php");
    $name = trim($_POST["course_name"]);
    $price = trim($_POST["course_price"]);
    $department = trim($_POST["course_department"]);
    $duration = trim($_POST["course_duration"]);

    $filename = $_FILES["image"]["name"];
    $tempname = $_FILES["image"]["tmp_name"];
    $folder = "assets/img/upload/" . $filename;



    // Insert image data into database
    $sql = "INSERT INTO course (course_name, course_image, course_price, course_duration, course_department) VALUES ('" . $name . "', '" . $filename . "','" . $price . "','" . $duration . "','" . $department . "')";

    if (mysqli_query($link, $sql)) {
        echo "<script>  success</script>";
    } else {
        echo "<script>  filed</script> ";
    }
    if (move_uploaded_file($tempname, $folder)) {
        echo "<script>  Image uploaded successfully!</script>";
    } else {
        echo "<script>  Failed to upload image!</script>";
    }
    mysqli_close($link);
 }
    
 
 

?>
    
        <div class="page-wrapper">

            <div class="content container-fluid pb-0">

                <div class="page-header">
                    <div class="row align-items-center">
                        <div class="col">
                            <h3 class="page-title">Course</h3>
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="admin-dashboard.php">Dashboard</a></li>
                                <li class="breadcrumb-item active">Course</li>
                            </ul>
                        </div>
                        <div class="col-auto float-end ms-auto">
                            <a href="#" class="btn add-btn" data-bs-toggle="modal" data-bs-target="#add_client"><i
                                    class="fa-solid fa-plus"></i> Add Course</a>
                            <div class="view-icons">
                                <a href="clients.html" class="grid-view btn btn-link active"><i
                                        class="fa fa-th"></i></a>
                                <a href="clients-list.html" class="list-view btn btn-link"><i
                                        class="fa-solid fa-bars"></i></a>
                            </div>
                        </div>
                    </div>
                </div>


                <div class="row filter-row">
                    <div class="col-sm-6 col-md-3">
                        <div class="input-block mb-3 form-focus">
                            <input type="text" class="form-control floating">
                            <label class="focus-label">Course ID</label>
                        </div>
                    </div>
                    <div class="col-sm-6 col-md-3">
                        <div class="input-block mb-3 form-focus">
                            <input type="text" class="form-control floating">
                            <label class="focus-label">Course Name</label>
                        </div>
                    </div>
                    <div class="col-sm-6 col-md-3">
                        <div class="input-block mb-3 form-focus select-focus">
                            <select class="select floating">
                                <option>Select Company</option>
                                <option>Global Technologies</option>
                                <option>Delta Infotech</option>
                            </select>
                            <label class="focus-label">Company</label>
                        </div>
                    </div>
                    <div class="col-sm-6 col-md-3">
                        <div class="d-grid">
                            <a href="#" class="btn btn-success"> Search </a>
                        </div>
                    </div>
                </div>

                <div class="row staff-grid-row">
                    
                    
                    <?php 
                        require("config.php");
                        $query = " select * from course ";
                        $result = mysqli_query($link, $query);
                        while ($data = mysqli_fetch_assoc($result)) {
                    ?>
                    <div class="col-md-4 col-sm-6 col-12 col-lg-4 col-xl-3 d-flex">
                        <div class="profile-widget w-100 ">
                            <div class="profile-img">
                                <a href="client-profile.html" class="avatar">
                                    <img src="assets/img/upload/<?php echo $data['course_image']; ?>" alt="User Image"></a>
                            </div>
                            <div class="dropdown profile-action">
                                <a href="#" class="action-icon dropdown-toggle" data-bs-toggle="dropdown"
                                    aria-expanded="false"><i class="material-icons">more_vert</i></a>
                                <div class="dropdown-menu dropdown-menu-right">
                                    <a class="dropdown-item" href="#" data-bs-toggle="modal"
                                        data-bs-target="#edit_client"><i class="fa-solid fa-pencil m-r-5"></i> Edit</a>
                                    <a class="dropdown-item" href="#" data-bs-toggle="modal"
                                        data-bs-target="#delete_client"><i class="fa-regular fa-trash-can m-r-5"></i>
                                        Delete</a>
                                </div>
                            </div>
                            <h4 class="user-name m-t-10 mb-0 text-ellipsis"><a href="client-profile.html"><?php echo $data['course_name']; ?></a></h4>
                            <div class="small text-muted"><?php echo $data['course_department']; ?></div>
                            <a href="client-profile.html" class="btn btn-success btn-sm m-t-10">View Profile</a>
                        </div>
                    </div>
                    <?php }  mysqli_close($link);?> 
                      
                </div>
            </div>


            <div id="add_client" class="modal custom-modal fade" role="dialog">
                <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title">Add Course</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <form action="" method="post" enctype="multipart/form-data">
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="input-block mb-3">
                                            <label class="col-form-label">Course Name <span
                                                    class="text-danger">*</span></label>
                                            <input class="form-control" name="course_name" type="text">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="input-block mb-3">
                                            <label class="col-form-label">Price</label>
                                            <input class="form-control" name="course_price" type="number">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="input-block mb-3" data-select2-id="select2-data-23-stdx">
                                            <label class="col-form-label">Department <span class="text-danger">*</span></label>
                                            <select name="course_department" class="select select2-hidden-accessible" data-select2-id="select2-data-7-nmfq" tabindex="-1" aria-hidden="true">
                                            <option value="Null" data-select2-id="select2-data-9-mw6i">Select Department</option>
                                            <option value="Development" data-select2-id="select2-data-29-plv8">Development</option>
                                            <option value="Testing" data-select2-id="select2-data-30-nh1n">Testing</option>
                                            <option value="Cloud" data-select2-id="select2-data-31-fryp">Cloud</option>
                                            <option value="Networking" data-select2-id="select2-data">Networking</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="input-block mb-3">
                                            <label class="col-form-label">Image <span class="text-danger">*</span></label>
                                            <input class="form-control floating" name="image" value="" type="file">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="input-block mb-3" data-select2-id="select2-data-1-zouz">
                                            <label class="col-form-label">Duration <span class="text-danger">*</span></label>
                                            <select name="course_duration" class="select select2-hidden-accessible" data-select2-id="select2-data-1-zouz" tabindex="-1" aria-hidden="true">
                                            <option value="0" data-select2-id="">Select Duration</option>
                                            <option value="2" data-select2-id="select2-data-129-plv8">2 Months</option>
                                            <option value="3" data-select2-id="select2-data-130-nh1n">3 Months</option>
                                            <option value="6" data-select2-id="select2-data-131-fryp">6 Months</option>
                                            </select>
                                        </div>
                                    </div>
                                     
                                     
                                     
                                </div>
                                
                                <div class="submit-section">
                                    <input type="submit" name="insert" class="btn btn-primary submit-btn">
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>


            <div id="edit_client" class="modal custom-modal fade" role="dialog">
                <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title">Edit Client</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <form>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="input-block mb-3">
                                            <label class="col-form-label">First Name <span
                                                    class="text-danger">*</span></label>
                                            <input class="form-control" value="Barry" type="text">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="input-block mb-3">
                                            <label class="col-form-label">Last Name</label>
                                            <input class="form-control" value="Cuda" type="text">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="input-block mb-3">
                                            <label class="col-form-label">Username <span
                                                    class="text-danger">*</span></label>
                                            <input class="form-control" value="barrycuda" type="text">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="input-block mb-3">
                                            <label class="col-form-label">Email <span
                                                    class="text-danger">*</span></label>
                                            <input class="form-control floating" value="barrycuda@example.com"
                                                type="email">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="input-block mb-3">
                                            <label class="col-form-label">Password</label>
                                            <input class="form-control" value="barrycuda" type="password">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="input-block mb-3">
                                            <label class="col-form-label">Confirm Password</label>
                                            <input class="form-control" value="barrycuda" type="password">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="input-block mb-3">
                                            <label class="col-form-label">Client ID <span
                                                    class="text-danger">*</span></label>
                                            <input class="form-control floating" value="CLT-0001" type="text">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="input-block mb-3">
                                            <label class="col-form-label">Phone </label>
                                            <input class="form-control" value="9876543210" type="text">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="input-block mb-3">
                                            <label class="col-form-label">Company Name</label>
                                            <input class="form-control" type="text" value="Global Technologies">
                                        </div>
                                    </div>
                                </div>
                                <div class="table-responsive m-t-15">
                                    <table class="table table-striped custom-table">
                                        <thead>
                                            <tr>
                                                <th>Module Permission</th>
                                                <th class="text-center">Read</th>
                                                <th class="text-center">Write</th>
                                                <th class="text-center">Create</th>
                                                <th class="text-center">Delete</th>
                                                <th class="text-center">Import</th>
                                                <th class="text-center">Export</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td>Projects</td>
                                                <td class="text-center">
                                                    <label class="custom_check">
                                                        <input type="checkbox" checked>
                                                        <span class="checkmark"></span>
                                                    </label>
                                                </td>
                                                <td class="text-center">
                                                    <label class="custom_check">
                                                        <input type="checkbox" checked>
                                                        <span class="checkmark"></span>
                                                    </label>
                                                </td>
                                                <td class="text-center">
                                                    <label class="custom_check">
                                                        <input type="checkbox" checked>
                                                        <span class="checkmark"></span>
                                                    </label>
                                                </td>
                                                <td class="text-center">
                                                    <label class="custom_check">
                                                        <input type="checkbox" checked>
                                                        <span class="checkmark"></span>
                                                    </label>
                                                </td>
                                                <td class="text-center">
                                                    <label class="custom_check">
                                                        <input type="checkbox" checked>
                                                        <span class="checkmark"></span>
                                                    </label>
                                                </td>
                                                <td class="text-center">
                                                    <label class="custom_check">
                                                        <input type="checkbox" checked>
                                                        <span class="checkmark"></span>
                                                    </label>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>Tasks</td>
                                                <td class="text-center">
                                                    <label class="custom_check">
                                                        <input type="checkbox" checked>
                                                        <span class="checkmark"></span>
                                                    </label>
                                                </td>
                                                <td class="text-center">
                                                    <label class="custom_check">
                                                        <input type="checkbox" checked>
                                                        <span class="checkmark"></span>
                                                    </label>
                                                </td>
                                                <td class="text-center">
                                                    <label class="custom_check">
                                                        <input type="checkbox" checked>
                                                        <span class="checkmark"></span>
                                                    </label>
                                                </td>
                                                <td class="text-center">
                                                    <label class="custom_check">
                                                        <input type="checkbox" checked>
                                                        <span class="checkmark"></span>
                                                    </label>
                                                </td>
                                                <td class="text-center">
                                                    <label class="custom_check">
                                                        <input type="checkbox" checked>
                                                        <span class="checkmark"></span>
                                                    </label>
                                                </td>
                                                <td class="text-center">
                                                    <label class="custom_check">
                                                        <input type="checkbox" checked>
                                                        <span class="checkmark"></span>
                                                    </label>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>Chat</td>
                                                <td class="text-center">
                                                    <label class="custom_check">
                                                        <input type="checkbox" checked>
                                                        <span class="checkmark"></span>
                                                    </label>
                                                </td>
                                                <td class="text-center">
                                                    <label class="custom_check">
                                                        <input type="checkbox" checked>
                                                        <span class="checkmark"></span>
                                                    </label>
                                                </td>
                                                <td class="text-center">
                                                    <label class="custom_check">
                                                        <input type="checkbox" checked>
                                                        <span class="checkmark"></span>
                                                    </label>
                                                </td>
                                                <td class="text-center">
                                                    <label class="custom_check">
                                                        <input type="checkbox" checked>
                                                        <span class="checkmark"></span>
                                                    </label>
                                                </td>
                                                <td class="text-center">
                                                    <label class="custom_check">
                                                        <input type="checkbox" checked>
                                                        <span class="checkmark"></span>
                                                    </label>
                                                </td>
                                                <td class="text-center">
                                                    <label class="custom_check">
                                                        <input type="checkbox" checked>
                                                        <span class="checkmark"></span>
                                                    </label>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>Estimates</td>
                                                <td class="text-center">
                                                    <label class="custom_check">
                                                        <input type="checkbox" checked>
                                                        <span class="checkmark"></span>
                                                    </label>
                                                </td>
                                                <td class="text-center">
                                                    <label class="custom_check">
                                                        <input type="checkbox" checked>
                                                        <span class="checkmark"></span>
                                                    </label>
                                                </td>
                                                <td class="text-center">
                                                    <label class="custom_check">
                                                        <input type="checkbox" checked>
                                                        <span class="checkmark"></span>
                                                    </label>
                                                </td>
                                                <td class="text-center">
                                                    <label class="custom_check">
                                                        <input type="checkbox" checked>
                                                        <span class="checkmark"></span>
                                                    </label>
                                                </td>
                                                <td class="text-center">
                                                    <label class="custom_check">
                                                        <input type="checkbox" checked>
                                                        <span class="checkmark"></span>
                                                    </label>
                                                </td>
                                                <td class="text-center">
                                                    <label class="custom_check">
                                                        <input type="checkbox" checked>
                                                        <span class="checkmark"></span>
                                                    </label>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>Invoices</td>
                                                <td class="text-center">
                                                    <label class="custom_check">
                                                        <input type="checkbox" checked>
                                                        <span class="checkmark"></span>
                                                    </label>
                                                </td>
                                                <td class="text-center">
                                                    <label class="custom_check">
                                                        <input type="checkbox" checked>
                                                        <span class="checkmark"></span>
                                                    </label>
                                                </td>
                                                <td class="text-center">
                                                    <label class="custom_check">
                                                        <input type="checkbox" checked>
                                                        <span class="checkmark"></span>
                                                    </label>
                                                </td>
                                                <td class="text-center">
                                                    <label class="custom_check">
                                                        <input type="checkbox" checked>
                                                        <span class="checkmark"></span>
                                                    </label>
                                                </td>
                                                <td class="text-center">
                                                    <label class="custom_check">
                                                        <input type="checkbox" checked>
                                                        <span class="checkmark"></span>
                                                    </label>
                                                </td>
                                                <td class="text-center">
                                                    <label class="custom_check">
                                                        <input type="checkbox" checked>
                                                        <span class="checkmark"></span>
                                                    </label>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>Timing Sheets</td>
                                                <td class="text-center">
                                                    <label class="custom_check">
                                                        <input type="checkbox" checked>
                                                        <span class="checkmark"></span>
                                                    </label>
                                                </td>
                                                <td class="text-center">
                                                    <label class="custom_check">
                                                        <input type="checkbox" checked>
                                                        <span class="checkmark"></span>
                                                    </label>
                                                </td>
                                                <td class="text-center">
                                                    <label class="custom_check">
                                                        <input type="checkbox" checked>
                                                        <span class="checkmark"></span>
                                                    </label>
                                                </td>
                                                <td class="text-center">
                                                    <label class="custom_check">
                                                        <input type="checkbox" checked>
                                                        <span class="checkmark"></span>
                                                    </label>
                                                </td>
                                                <td class="text-center">
                                                    <label class="custom_check">
                                                        <input type="checkbox" checked>
                                                        <span class="checkmark"></span>
                                                    </label>
                                                </td>
                                                <td class="text-center">
                                                    <label class="custom_check">
                                                        <input type="checkbox" checked>
                                                        <span class="checkmark"></span>
                                                    </label>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                                <div class="submit-section">
                                    <button class="btn btn-primary submit-btn">Save</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>


            <div class="modal custom-modal fade" id="delete_client" role="dialog">
                <div class="modal-dialog modal-dialog-centered">
                    <div class="modal-content">
                        <div class="modal-body">
                            <div class="form-header">
                                <h3>Delete Client</h3>
                                <p>Are you sure want to delete?</p>
                            </div>
                            <div class="modal-btn delete-action">
                                <div class="row">
                                    <div class="col-6">
                                        <a href="javascript:void(0);" class="btn btn-primary continue-btn">Delete</a>
                                    </div>
                                    <div class="col-6">
                                        <a href="javascript:void(0);" data-bs-dismiss="modal"
                                            class="btn btn-primary cancel-btn">Cancel</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>



        </div>

<?php include("footer.php")?>