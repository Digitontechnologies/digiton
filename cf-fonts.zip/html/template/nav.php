<body>

    <div class="main-wrapper">

        <div class="header">

            <div class="header-left">
                <a href="admin-dashboard.html" class="logo">
                    <img src="assets/img/logo.png" alt="Logo">
                </a>
                <a href="admin-dashboard.html" class="logo collapse-logo">
                    <img src="assets/img/logo-small.png" alt="Logo">
                </a>
                <a href="admin-dashboard.html" class="logo2">
                    <img src="assets/img/logo-small.png" width="40" height="40" alt="Logo">
                </a>
            </div>

            <a id="toggle_btn" href="javascript:void(0);">
                <span class="bar-icon">
                    <span></span>
                    <span></span>
                    <span></span>
                </span>
            </a>

            <div class="page-title-box">
                <h3>Digiton Technologies</h3>
            </div>

            <a id="mobile_btn" class="mobile_btn" href="#sidebar"><i class="fa-solid fa-bars"></i></a>

            <ul class="nav user-menu">
                <li class="nav-item dropdown has-arrow main-drop">
                    <a href="#" class="dropdown-toggle nav-link" data-bs-toggle="dropdown">
                        <span class="user-img"><img src="assets/img/avatar/avatar-27.jpg" alt="User Image">
                            <span class="status online"></span></span>
                        <span><?php echo $_SESSION["username"] ?></span>
                    </a>
                    <div class="dropdown-menu">
                        <a class="dropdown-item" href="profile.html">My Profile</a>
                        <a class="dropdown-item" href="settings.html">Settings</a>
                        <a class="dropdown-item" href="?logout=true">Logout</a>
                    </div>
                </li>
            </ul>


            <div class="dropdown mobile-user-menu">
                <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false"><i
                        class="fa-solid fa-ellipsis-vertical"></i></a>
                <div class="dropdown-menu dropdown-menu-right">
                    <a class="dropdown-item" href="profile.html">My Profile</a>
                    <a class="dropdown-item" href="settings.html">Settings</a>
                    <a class="dropdown-item" href="?logout=true">Logout</a>
                </div>
            </div>
        </div>

        <div class="sidebar" id="sidebar">
            <div class="sidebar-inner slimscroll">
                <div id="sidebar-menu" class="sidebar-menu">

                    <ul class="sidebar-vertical">

                        <li class="submenu">
                            <a href="#"><i class="la la-dashcube"></i> <span> Dashboard</span> <span
                                    class="menu-arrow"></span></a>
                            <ul>
                                <li><a href="admin-dashboard.php" class="active">Admin Dashboard</a></li>
                                <li><a href="employee-dashboard.php">Employee Dashboard</a></li>
                                <li><a href="student-dashboard.php">Student Dashboard</a></li>
                                <li><a href="course-dashboard.php">Course Dashboard</a></li>
                            </ul>
                        </li>

                        <li class="submenu">
                            <a href="#"><i class="la la-user-plus"></i> <span> Students</span> <span
                                    class="menu-arrow"></span></a>
                            <ul>
                                <li><a href="employees.html">All Students</a></li>
                                <li><a href="holidays.html">Add New Students</a></li>
                                <li><a href="leaves-employee.html">Delete Students</a></li>


                            </ul>
                        </li>
                        <li class="submenu">
                            <a href="#"><i class="la la-user"></i> <span> Employees</span> <span
                                    class="menu-arrow"></span></a>
                            <ul>
                                <li><a href="employees.html">All Employees</a></li>
                                <li><a href="holidays.html">Holidays</a></li>
                                <li><a href="leaves-employee.html">Leaves (Employee)</a></li>

                            </ul>
                        </li>

                        <li class="submenu">
                            <a href="#"><i class="la la-users"></i> <span> Clients</span> <span
                                    class="menu-arrow"></span></a>
                            <ul>
                                <li><a href="projects.html">Manage</a></li>
                                <li><a href="tasks.html">Add Client</a></li>

                            </ul>
                        </li>
                        <li class="submenu">
                            <a href="#"><i class="la la-ticket"></i> <span>Invoice</span><span
                                    class="menu-arrow"></span></a>
                            <ul>
                                <li><a href="tickets.html">Fees Receipt</a></li>
                                <li><a href="ticket-details.html">Outstanding </a></li>
                            </ul>
                        </li>

                        <li class="submenu">
                            <a href="#"><i class="la la-chart-line"></i> <span> Attendance </span> <span
                                    class="menu-arrow"></span></a>
                            <ul>
                                <li><a href="chart-apex.html">View Attendance</a></li>
                                <li><a href="chart-js.html">Add Attendance</a></li>

                            </ul>
                        </li>
                        <li class="submenu">
                            <a href="#"><i class="la la-icons"></i> <span> Courses </span> <span
                                    class="menu-arrow"></span></a>
                            <ul>
                                <li><a href="icon-fontawesome.html">View Courses</a></li>
                                <li><a href="icon-feather.html">Add Courses</a></li>
                            </ul>
                        </li>


                    </ul>
                </div>
            </div>
        </div>